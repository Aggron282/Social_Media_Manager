const router = require("express").Router();
const socialController = require("../controllers/social.js");

// Start LinkedIn OAuth to link account
router.get('/auth/linkedin', socialController.LinkedinStart);

// Handle LinkedIn callback and store access token
router.get('/auth/linkedin/callback', socialController.LinkedinCallback);

module.exports = router;
