// This starts the LinkedIn OAuth flow
const LINKEDIN_CLIENT = process.env.LINKEDIN_CLIENT;
const LINKEDIN_SECRET = process.env.LINKEDIN_SECRET;
const LINKEDIN_REDIRECT = process.env.LINKEDIN_REDIRECT;
const axios = require("axios");
const User = require("./../models/User.js");
const LinkedinStart = (req, res) => {
  const scope = 'w_member_social';
  const state = 'optional_csrf_token';
  console.log(req.session,"S");

  const authURL = `https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=${LINKEDIN_CLIENT}&redirect_uri=${encodeURIComponent(LINKEDIN_REDIRECT)}&scope=${encodeURIComponent(scope)}&state=${state}`;

  res.redirect(authURL);
};

const LinkedinCallback = async (req, res) => {
  const { code } = req.query;
  console.log(req.session);
  if (!code) return res.status(400).send("Missing code");

  try {
    const tokenResponse = await axios.post('https://www.linkedin.com/oauth/v2/accessToken', null, {
      params: {
        grant_type: 'authorization_code',
        code,
        redirect_uri: LINKEDIN_REDIRECT,
        client_id: LINKEDIN_CLIENT,
        client_secret: LINKEDIN_SECRET,
      },
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });

    const { access_token, expires_in } = tokenResponse.data;
    console.log(req.session.user)
    const user = await User.findById(req.session.user._id);
    if (!user) return res.status(401).send("User not found");

    const platform = "linkedin";

    const existing = user.socialMedia.find(acc => acc.platform === platform);

    if (existing) {
      existing.key.accessToken = access_token;
      existing.key.expiresAt = new Date(Date.now() + expires_in * 1000);
    } else {
      user.socialMedia.push({
        platform,
        username: "", // optional
        password: "",
        key: {
          accessToken: access_token,
          expiresAt: new Date(Date.now() + expires_in * 1000),
        },
      });
    }

    await user.save();

    req.session.linkedinAccessToken = access_token;
    req.session.linkedinTokenExpiry = Date.now() + expires_in * 1000;

    res.redirect("http://localhost:3000/dashboard");
  } catch (error) {
    console.error('Error exchanging code:', error.response?.data || error.message);
    res.status(500).send('Failed to link LinkedIn');
  }
};

module.exports.LinkedinCallback = LinkedinCallback;
module.exports.LinkedinStart = LinkedinStart;
